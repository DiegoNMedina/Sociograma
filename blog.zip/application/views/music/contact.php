<!-- contact_rsvp -->
<div class="contact_rsvp">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="text text-center">
                    <h3>CONTACT ME TO PRODUCE MUSIC :)</h3>
                    <a class="boxed-btn3" href="tel://<?php echo $mphone ?>">Call me</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--/ contact_rsvp -->