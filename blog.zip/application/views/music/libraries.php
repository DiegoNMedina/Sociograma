 <!-- link that opens popup -->

 <!-- JS here -->
 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
 </script>
 <script src="<?= base_url(); ?>assets/music/js/vendor/modernizr-3.5.0.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/vendor/jquery-1.12.4.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/popper.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/bootstrap.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/owl.carousel.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/isotope.pkgd.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/ajax-form.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/waypoints.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.counterup.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/imagesloaded.pkgd.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/audioplayer.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/scrollIt.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.scrollUp.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/wow.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/nice-select.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.slicknav.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.magnific-popup.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/plugins.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/gijgo.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/slick.min.js"></script>
 <!--contact js-->
 <script src="<?= base_url(); ?>assets/music/js/contact.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.ajaxchimp.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.form.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/jquery.validate.min.js"></script>
 <script src="<?= base_url(); ?>assets/music/js/mail-script.js"></script>

 <script src="<?= base_url(); ?>assets/music/js/main.js"></script>

 <script>
     $(function() {
         $('audio').audioPlayer({

         });
     });
 </script>
 </body>

 </html>