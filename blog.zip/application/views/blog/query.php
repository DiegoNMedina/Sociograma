<?php


foreach ($resultados as $key) {

    echo $key['Code'];
}


?>