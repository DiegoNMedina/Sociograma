<!-- SLIDER -->
<div class="site-blocks-cover overlay" style="background-image: url(<?= base_url() ?>assets/theraphy/images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-10">
                <div class="row justify-content-center mb-4">
                    <div class="col-md-10 text-center">
                        <h1 data-aos="fade-up" class="mb-5">Daré soluciones a tu <span class="typed-words"></span></h1>
                        <p data-aos="fade-up" data-aos-delay="100"><a href="#" class="btn btn-primary btn-pill">Empezar</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- END SLIDER -->