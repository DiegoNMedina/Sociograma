<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'blog';
$route['404_override'] = 'notfound/index';
$route['translate_uri_dashes'] = FALSE;

$route['Miguel_Jr'] = "Music/Index";


$route['LTF_AndreaH'] = "Theraphy";
$route['LTF_AndreaH/About'] = "Theraphy/about";
